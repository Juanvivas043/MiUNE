/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package clasepro4;

/**
 *
 * @author nieldm
 */

//En esta clase se expone el polimorfismo
public class Analizador {

    public Analizador() {
    }
    
    //Creamos el metodo con el mismo nombre cuyo dato de entrada sean diferentes
    
    public void revisar(perro p){
        System.out.println("\nPerro 1");
        System.out.println(" Nombre: " + p.nombre);
        System.out.println("   Raza: " + p.raza);
        System.out.println("   Edad: " + p.edad);
        p.ladrar();
    }
    //Vemos que la diferencia entre estos dos metods es el tipo de dato que recibe lo cual en este caso
    //es perro o gato es sus proyecto por ejemplo pueden ser Guerrero o Mago
    //a la hora de ejecutar el compilador verifica que tipo de dato esta recibiendo y ejecuta 
    //el que concide vemos que si recibe un tipo de dato "perro" ejecuta el metodo de arriba y
    //de recibir "gato" ejecuta el de abajo
        public void revisar(gato g){
        System.out.println("\nGato 1");
        System.out.println(" Nombre: " + g.nombre);
    }
}
