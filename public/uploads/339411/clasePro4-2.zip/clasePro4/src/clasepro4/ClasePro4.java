/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package clasepro4;

import java.io.*; //importamos la clase necesaria para capturar datos
/**
 *
 * @author nieldm
 */
public class ClasePro4 {
    private static String prueba;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        System.out.println("Hola Mundo!!");
        
        System.out.println("\n-- Clase 1 de ProIV --");
        
        perro perro1, perro2;
        gato gato1;
        
        perro1 = new perro();
        perro2 = new perro("Schauzer", "Royal", 3);
        
        gato1 = new gato();
        
        System.out.println("\nPerro 1");
        System.out.println(" Nombre: " + perro1.nombre);
        System.out.println("   Raza: " + perro1.raza);
        System.out.println("   Edad: " + perro1.edad);
        
        System.out.println("\nPerro 2");
        System.out.println(" Nombre: " + perro2.nombre);
        System.out.println("   Raza: " + perro2.raza);
        System.out.println("   Edad: " + perro2.edad);
        
        perro2.decirfamilia(); //Metodo de la clase Padre
        gato1.decirfamilia();
        
        System.out.println("\n-- Clase 1 de ProIV --");
        
        System.out.println("\n-Prueba de Polimorfismo-");
        
        Analizador anl;
        anl = new Analizador();
        //Probamos el polimorfismo que realizamos en la Clase Analizador
        System.out.println("\n Que pasa si le pasamos una clase 'gato'?");
        anl.revisar(gato1);
        System.out.println("\n Que pasa si le pasamos una clase 'perro'?");
        anl.revisar(perro2);
        
        System.out.println("\n-Captura de Datos-\n");
        //Creación del flujo para leer datos
        InputStreamReader isr = new InputStreamReader(System.in);
        
        //Creación del filtro para optimizar la lectura de datos
        BufferedReader br = new BufferedReader(isr);
        System.out.print("Teclea lo que desee: \n");
        
        prueba = new String();
        prueba = br.readLine();
        
        System.out.println("Usted escribió: " + prueba);
        
        
        
        
        
        
    }
}
