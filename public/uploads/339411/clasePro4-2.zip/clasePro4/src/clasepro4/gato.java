/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package clasepro4;

/**
 *
 * @author nieldm
 */
public class gato extends mamifero {
    String nombre;
    
    public gato() {
        super();
        nombre = "cualquiera";  
    }

    public String getNombre() {
        return nombre;
    }
    
}
