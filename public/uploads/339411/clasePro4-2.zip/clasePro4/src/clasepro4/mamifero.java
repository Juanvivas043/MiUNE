/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package clasepro4;

/**
 *
 * @author nieldm
 */
public class mamifero {
    String familia;
    
    mamifero(){
        familia = "defecto";
    }
    mamifero(String f){
        familia = f;
    }
    
    public void decirfamilia(){
        System.out.println("Familia: " + familia);
    }
    
    
    
}
