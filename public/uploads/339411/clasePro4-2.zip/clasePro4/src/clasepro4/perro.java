/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package clasepro4;

/**
 *
 * @author nieldm
 */
public class perro extends mamifero {
    
    String raza;
    String nombre;
    int edad;
    
    //Si no se le pasa ningun parametro para contruir, coloca valores por defecto
    perro(){
        super("cánidos");
          raza = "cacri";
        nombre = "perro";
          edad = 5;
    }
    
    perro(String r, String n, int e){
        super("cánidos");
          raza = r;
        nombre = n;
          edad = e;    
    }
    
    public void ladrar(){
        System.out.println("Woof!");
    }
    
}
